import os
import sys
from pathlib import Path

def list_directory_tree(directory_path, exclude_dirs=None, indent="", is_last=True, print_full_path=False):
    """
    Lista a estrutura de diretórios recursivamente, excluindo diretórios específicos.
    
    Args:
        directory_path (Path): Caminho do diretório a ser listado
        exclude_dirs (list): Lista de nomes de diretórios a serem excluídos
        indent (str): Indentação atual para formatação
        is_last (bool): Se é o último item no nível atual
        print_full_path (bool): Se deve imprimir o caminho completo ou apenas o nome
    """
    if exclude_dirs is None:
        exclude_dirs = ["node_modules"]
    
    # Caracteres para a árvore
    prefix = "└── " if is_last else "├── "
    
    # Nome a ser exibido
    display_name = str(directory_path) if print_full_path else directory_path.name
    
    # Imprime o diretório atual
    print(f"{indent}{prefix}{display_name}")
    
    # Prepara a indentação para os filhos
    next_indent = indent + ("    " if is_last else "│   ")
    
    # Lista todos os arquivos e diretórios
    try:
        items = sorted(list(directory_path.iterdir()), 
                       key=lambda x: (x.is_file(), x.name.lower()))
    except PermissionError:
        print(f"{next_indent}└── [Acesso negado]")
        return
    
    # Filtra os itens, excluindo diretórios da lista exclude_dirs
    filtered_items = [item for item in items if not (item.is_dir() and item.name in exclude_dirs)]
    
    # Processa cada item
    for i, item in enumerate(filtered_items):
        is_last_item = (i == len(filtered_items) - 1)
        
        if item.is_dir():
            # Se for um diretório, chama recursivamente
            list_directory_tree(item, exclude_dirs, next_indent, is_last_item, print_full_path)
        else:
            # Se for um arquivo, apenas imprime
            file_prefix = "└── " if is_last_item else "├── "
            file_name = str(item) if print_full_path else item.name
            print(f"{next_indent}{file_prefix}{file_name}")

def main():
    """Função principal que processa os argumentos da linha de comando."""
    # Configuração padrão
    directory = Path.cwd()  # Diretório atual por padrão
    exclude_dirs = ["node_modules"]
    print_full_path = False
    
    # Verifica argumentos da linha de comando
    if len(sys.argv) > 1:
        # Se um caminho foi fornecido
        path_arg = sys.argv[1]
        directory = Path(path_arg)
    
    # Verifica se diretório existe
    if not directory.exists() or not directory.is_dir():
        print(f"Erro: '{directory}' não é um diretório válido.")
        return
    
    # Processa argumentos adicionais
    for arg in sys.argv[2:]:
        if arg == "--full-path":
            print_full_path = True
        elif arg.startswith("--exclude="):
            # Permite excluir diretórios adicionais, separados por vírgula
            exclude_arg = arg.split("=")[1]
            additional_excludes = [dir_name.strip() for dir_name in exclude_arg.split(",")]
            exclude_dirs.extend(additional_excludes)
    
    print(f"Estrutura do projeto em: {directory}")
    print(f"Excluindo: {', '.join(exclude_dirs)}")
    print("-" * 50)
    
    # Chama a função para listar a estrutura
    list_directory_tree(directory, exclude_dirs, print_full_path=print_full_path)

if __name__ == "__main__":
    main()